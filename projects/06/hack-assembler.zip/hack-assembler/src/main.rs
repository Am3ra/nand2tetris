use std::collections::HashMap;
use std::fs::{self, *};
use std::io::{self, Read};
use std::path::PathBuf;
use structopt::StructOpt;

#[derive(Debug, StructOpt)]
#[structopt(name = "example", about = "An example of StructOpt usage.")]
struct Opt {
    /// Activate debug mode
    // short and long flags (-d, --debug) will be deduced from the field's name
    #[structopt(short, long)]
    debug: bool,

    /// Input file, stdin if not present
    #[structopt(short, long, parse(from_os_str))]
    input: Option<PathBuf>,

    /// Output file, stdout if not present
    #[structopt(short, long, parse(from_os_str))]
    output: Option<PathBuf>,
}
fn main() {
    // println!("{:015b}",21);
    let opt = Opt::from_args();
    if opt.debug {
        println!("{:?}", opt);
    }
    let input_file: String = get_input(&opt);

    let output_file = assemble_file(input_file, &opt);

    write_output(output_file, &opt);
}

fn get_input(opt: &Opt) -> String {
    if let Some(path) = &opt.input {
        read_to_string(path).expect("Input file")
    } else {
        let mut input_file = String::new();
        io::stdin()
            .read_to_string(&mut input_file)
            .expect("Input file");
        input_file
    }
}

fn strip_comment<'a>(input: &'a str) -> &'a str {
    input
        .find("//")
        .map(|idx| &input[..idx])
        .unwrap_or(input)
        .trim()
}

fn assemble_file(input_file: String, opt: &Opt) -> String {
    let mut output_file = String::new();
    let mut symbol_table: HashMap<String, u32> = 
        [
        ("R0".into(), 0),
        ("R1".into(), 1),
        ("R2".into(), 2),
        ("R3".into(), 3),
        ("R4".into(), 4),
        ("R5".into(), 5),
        ("R6".into(), 6),
        ("R7".into(), 7),
        ("R8".into(), 8),
        ("R9".into(), 9),
        ("R10".into(), 10),
        ("R11".into(), 11),
        ("R12".into(), 12),
        ("R13".into(), 13),
        ("R14".into(), 14),
        ("R15".into(), 15),
        ("SCREEN".into(), 16384),
        ("KBD".into(), 24576),
        ("SP".into(), 0),
        ("LCL".into(), 1),
        ("ARG".into(), 2),
        ("THIS".into(), 3),
        ("THAT".into(), 4),
        ]
        .iter().cloned().collect();
    let mut instruction: u32 = 0;
    let mut register_num: u32 = 15;

    for line in input_file.lines() {
        pre_process_jumps(
            strip_comment(line),
            opt,
            &mut symbol_table,
            &mut instruction,
        );
    }
    

    instruction = 0;

    
    for line in input_file.lines() {
        output_file.push_str(&translate_line(
            strip_comment(line),
            opt,
            &mut symbol_table,
            &mut instruction,
            &mut register_num,
        ));
    }


    if opt.debug{
        println!("Symbol table: {:#?}",symbol_table);
    }

    output_file
}

fn pre_process_jumps(line: &str,
    opt: &Opt,
    symbol_table: &mut HashMap<String, u32>,
    instruction: &mut u32,
) {
    
    if line.is_empty() {
        return;
    }

    match line.chars().nth(0) {
        Some('@') => {
            *instruction += 1;
        }

        Some('(') => {
            if let Some(')') = line.chars().last() {
                symbol_table
                    .entry(line[1..line.len() - 1].into())
                    .or_insert(instruction.clone());
                
                if opt.debug{
                    println!("Instruction pointer inserted: {}, with variable name: {}", instruction, &line[1..line.len() - 1]);
                }
            } else {
                panic!(format!("Syntax error on line: {}", instruction));
            }
        }

        Some(_) => {
            //Jump bits
            *instruction += 1;
        }

        None => (),
    }

}

fn translate_line(
    line: &str,
    opt: &Opt,
    symbol_table: &mut HashMap<String, u32>,
    instruction: &mut u32,
    register_num: &mut u32,
) -> String {
    if opt.debug {
        println!("{}", line);
    }

    if line.is_empty() {
        return line.into();
    }

    match line.chars().nth(0) {
        Some('@') => {
            *instruction += 1;
            match line[1..].parse(){
                Ok(num)=>{
                    let bin:u16 = num;
                    format!("0{:015b}\n", bin)
                }
                Err(_)=>{
                    let val = symbol_table
                        .entry(line[1..].into())
                        .or_insert_with(|| {
                            *register_num += 1;
                            if opt.debug{
                                println!("Register num incremented to {}",register_num);
                            }
                            register_num.clone()
                        });
                    
                    
                    format!("0{:015b}\n", val)
                }
            }

        }

        Some('(') => {
            if let Some(')') = line.chars().last() {
                symbol_table
                    .entry(line[1..line.len() - 1].into())
                    .or_insert_with( ||
                        {
                            if opt.debug{
                                println!("Instruction pointer inserted: {}, with variable name: {}", instruction, &line[1..line.len() - 1]);
                            }
                            instruction.clone()
                        }
                    );
                
                
                String::new()
            } else {
                panic!(format!("Syntax error on line: {}", instruction));
            }
        }

        Some(_) => {
            //Jump bits
            *instruction += 1;
            
            let jmp: &str = find_jump_bits(line, instruction,opt);
            let dest: &str = find_dest_bits(line, instruction,opt);
            let comp: &str = find_comp_bits(line, instruction,opt);


            format!("111{}{}{}\n",comp,dest,jmp)
        }

        None => String::new(),
    }
}

fn find_jump_bits<'a>(line:&'a str,instruction: &mut u32,opt: &Opt,)->&'a str{

    match line.find(';'){
        Some(n) => {
            let (_,right) = line.split_at(n);
            if opt.debug{
                println!("jmp bits: {}",&right[1..]);
            }
            match &right[1..]{
                "JMP" => "111",
                "JGT" => "001",
                "JEQ" => "010",
                "JGE" => "011",
                "JLT" => "100",
                "JNE" => "101",
                "JLE" => "110",
                _ => panic!(format!("Error near jump instruction{}, around {}",instruction,&right[1..])),
            }
        }
        None=>{
            "000"
        }
    }
}
fn find_dest_bits<'a>(line:&'a str,instruction: &mut u32,opt: &Opt,)->&'a str{

    match line.find('='){
        Some(n) => {
            let (left,_) = line.split_at(n);
            if opt.debug{
                println!("dest bits: {}",left);
            }
            match left{
                "M" => "001",
                "D" => "010",
                "MD" => "011",
                "A" => "100",
                "AM" => "101",
                "AD" => "110",
                "AMD" => "111",
                _ => panic!(format!("Error near dest instruction{}, around {}",instruction,&left[1..])),
            }
        }
        None=>{
            "000"
        }
    }
}
fn find_comp_bits<'a>(line:&'a str,instruction: &mut u32,opt: &Opt)->&'a str{

    let dest_location = {
        match line.find("="){
            Some(location)=>location+1,
            None=> 0 
        }
    };
    let jump_location = line.find(";").unwrap_or(line.len());
    let comp = &line[dest_location..jump_location];
    if opt.debug{
        println!("comp bits: {}",comp);
    }
    match comp{
        "0"     =>"0101010",
        "1"     =>"0111111",
        "-1"    =>"0111010",
        "D"     =>"0001100",
        "A"     =>"0110000",
        "M"     =>"1110000",
        "!D"    =>"0001101",
        "!A"    =>"0110001",
        "!M"    =>"1110001",
        "-D"    =>"0001111",
        "-A"    =>"0110011",
        "-M"    =>"1110011",
        "D+1"   =>"0011111",
        "A+1"   =>"0110111",
        "M+1"   =>"1110111",
        "D-1"   =>"0001110",
        "A-1"   =>"0110010",
        "M-1"   =>"1110010",
        "D+A"   =>"0000010",
        "D+M"   =>"1000010",
        "D-A"   =>"0010011",
        "D-M"   =>"1010011",
        "A-D"   =>"0000111",
        "M-D"   =>"1000111",
        "D&A"   =>"0000000",
        "D&M"   =>"1000000",
        "D|A"   =>"0010101",
        "D|M"   =>"1010101",
        _ => panic!(format!("Error near instruction{}, around {}",instruction,&comp[1..])),
    }
}

fn write_output(output: String, opt: &Opt) {
    if let Some(path) = &opt.output {
        fs::write(path, output).expect("error writing to file");
    } else {
        println!("RESULTS:");
        println!("{}", output);
    }
}
